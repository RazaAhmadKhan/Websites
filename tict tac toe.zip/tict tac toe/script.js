function startTicTacToe() {
    const gameArea = document.getElementById('gameArea');
    gameArea.innerHTML = `
        <h2>Tic-Tac-Toe</h2>
        <table id="tictactoe">
            <tr>
                <td onclick="makeMove(this, 0, 0)"></td>
                <td onclick="makeMove(this, 0, 1)"></td>
                <td onclick="makeMove(this, 0, 2)"></td>
            </tr>
            <tr>
                <td onclick="makeMove(this, 1, 0)"></td>
                <td onclick="makeMove(this, 1, 1)"></td>
                <td onclick="makeMove(this, 1, 2)"></td>
            </tr>
            <tr>
                <td onclick="makeMove(this, 2, 0)"></td>
                <td onclick="makeMove(this, 2, 1)"></td>
                <td onclick="makeMove(this, 2, 2)"></td>
            </tr>
        </table>
        <button id="resetBtn" onclick="resetTicTacToe()">Reset</button>
    `;
    currentPlayer = 'X';
    board = [
        ['', '', ''],
        ['', '', ''],
        ['', '', '']
    ];
}

let currentPlayer = 'X';
let board = [
    ['', '', ''],
    ['', '', '']
];

function makeMove(cell, row, col) {
    if (board[row][col] === '') {
        board[row][col] = currentPlayer;
        cell.innerHTML = currentPlayer;
        if (checkWin(currentPlayer)) {
            setTimeout(() => {
                showPopup(currentPlayer + ' wins!');
            }, 100);
        } else {
            currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        }
    }
}

function checkWin(player) {
    // Check rows
    for (let row = 0; row < 3; row++) {
        if (board[row][0] === player && board[row][1] === player && board[row][2] === player) {
            return true;
        }
    }
    // Check columns
    for (let col = 0; col < 3; col++) {
        if (board[0][col] === player && board[1][col] === player && board[2][col] === player) {
            return true;
        }
    }
    // Check diagonals
    if (board[0][0] === player && board[1][1] === player && board[2][2] === player) {
        return true;
    }
    if (board[0][2] === player && board[1][1] === player && board[2][0] === player) {
        return true;
    }
    return false;
}

function resetTicTacToe() {
    const cells = document.querySelectorAll('#tictactoe td');
    cells.forEach(cell => cell.innerHTML = '');
    board = [
        ['', '', ''],
        ['', '', '']
    ];
    currentPlayer = 'X';
}

function showPopup(message) {
    document.getElementById('winnerText').innerText = message;
    document.getElementById('popup').style.display = 'block';
}

function closePopup() {
    document.getElementById('popup').style.display = 'none';
    resetTicTacToe();
}

function startRPS() {
    const gameArea = document.getElementById('gameArea');
    gameArea.innerHTML = `
        <h2>Rock-Paper-Scissors</h2>
        <div>
            <button class="rpsBtn" onclick="playRPS('rock')">Rock</button>
            <button class="rpsBtn" onclick="playRPS('paper')">Paper</button>
            <button class="rpsBtn" onclick="playRPS('scissors')">Scissors</button>
        </div>
        <div id="rpsResult"></div>
    `;
}

function playRPS(playerChoice) {
    const choices = ['rock', 'paper', 'scissors'];
    const computerChoice = choices[Math.floor(Math.random() * 3)];
    const result = getResult(playerChoice, computerChoice);
    document.getElementById('rpsResult').innerHTML = `
        <p>You chose: ${playerChoice}</p>
        <p>Computer chose: ${computerChoice}</p>
        <p>${result}</p>
    `;
}

function getResult(player, computer) {
    if (player === computer) {
        return "It's a tie!";
    }
    if (
        (player === 'rock' && computer === 'scissors') ||
        (player === 'paper' && computer === 'rock') ||
        (player === 'scissors' && computer === 'paper')
    ) {
        return "You win!";
    } else {
        return "You lose!";
    }
}
